#!/sbin/sh
touch /cache/recovery/boot;
sync;
reboot;
